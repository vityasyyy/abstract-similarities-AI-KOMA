# abstract-similarities-AI-KOMA
## Nama & NIM
Muhammad Argya Vityasy (23/522547/PA/22475)
## Deskripsi
Tugas Mata Kuliah Kecerdasan Artifisial KOM A UGM. Membandingkan kesamaan antar abstract menggunakan 2 fitur representasi dan 2 cara perhitungan similaritas
